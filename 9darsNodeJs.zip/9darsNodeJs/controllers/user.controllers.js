import { writeFile, readFile } from "../helper/database.js";

const registerController = async (req, res) => {
    const {
        username,
        password,
        fullname,
        age,
        email,
        gender
    } = req.body;

    try {
        const data = await readFile("Users.json");
        const users = JSON.parse(data);

        let exist = false;
        users.forEach(user => {
            if (user.email === email || user.username === username) {
                exist = true;
                res.send(`${username} is already exists. Sorry!!!`);
            }
        });

        if (!exist) {
            const user = { ...req.body, id: users.length + 1 };
            users.push(user);
            await writeFile("users.json", JSON.stringify(users));
            delete user.password; 
            res.send(user);
        }
    } catch (error) {
        console.error("Error:", error);
        res.status(500).send("Internal Server Error");
    }
};

export default registerController;
