# Blog Website
## Users
   ## register
```
id: number,
username: string unique min-3,
password: string min-5,
fullName: string min-10 optional,
age: number min min-10,
email: string,
gender: string "male"/"female" optinal,
```

### Login
```
username | email : string,
password: string,
```
### Blog
```
id: string, 
tittle: string,
slug: string,
content: string,
tags: [string, string],
```
### User
```
REGISTER - POST
LOGIN - POST
PROFILE - GET, localhost:3000/username | localhost:3000/email |localhost:3000/is
```

### BLOG
```
CREATE - POST localhost:3000/blog
READ - GET localhost:3000/blog
UPDATE - PUT localhost:3000/blog/id
DELETE - DELETE localhost:3000/blog/id
```
