import express from "express"
import fs from "fs"
import path from "path"
import {router as ResisterRouter} from "./routes/users.route.js"
import {writeFile, readFile} from "../helper/database.js"



export const express=new Router()

router.post(`/`, async(req,res)=>{
    const {
        username,
        password,
        fullname,
        age,
        email,
        gender
    }=req.body
    const data =await readFile("Users.jon")
    let exist =false
    users.forEach(user => {
        if (user.email === email || user.username ===username){
            exist=true
            res.send(`${username} is already exists Sorry!!!`)
        }
    });
    if (exist){
        res.send(`${username} is already exist`)
    } else {
        const user={...req.body, id: users.lenght+1}

        users.push(user)
        writeFile("users.json", users)
        delete user.password()
        res.send(user)
    };
    res.send("OK")
})

app.use(`/regiter`,ResisterRouter)