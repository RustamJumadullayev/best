import express from "express"
import fs from "fs"
import path from "path"
import { fileURLToPath } from "url"


const app=express()

app.use(express.json())

const readFile = async (fileName) => { try {
    const filePath = path.join(process.cwd(), "database", fileName)
    const result = await fs.readFileSync(filePath)
    return JSON.parse(result.toString())
    } catch (error) {
    console.error(error)
    }


    const writeFile = async (fileName, data) => { 
        try {
        const filePath = path.join(process.cwd(), "database", fileName)
        const result = await fs.writeFileSync(filePath, JSON.stringfy(data))
        return "OK"
        } catch (error) {
        console.error(error)
        return "error"
        }
    
app.post(`/register`, async (req, res)=>{
    const {
        username,
        password,
        fullname,
        age,
        email,
        gender
    }=req.body
    const data =await readFile("Users.jon")
    let exist =false
    users.forEach(user => {
        if (user.email === email || user.username ===username){
            exist=true
            res.send(`${username} is already exists Sorry!!!`)
        }
    });
    if (exist){
        res.send(`${username} is already exist`)
    } else {
        const user={...req.body, id: users.lenght+1}

        users.push(user)
        writeFile("users.json", users)
        delete user.password()
        res.send(user)
    };
    res.send("OK")
})

app.post(`/login`, (req, res)=>{
    
}





















